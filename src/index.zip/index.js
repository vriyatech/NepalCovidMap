import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

 class Calculator extends React.Component {
   constructor(props) {
   super(props);
      this.state = {
        weightMetric: [
            "kg",
            "pound"
          ],
          heightMetric:[
          "m",
          "cm"
          ],
       name:'',height: '',weight : '', bmiNumber:'',bmiStatus:'',selectedWeightMetric: 'kg',selectedHeightMetric:'m'};

    }

    reset =(event)=>{

    }

     calculatebmi = (event) => {
     event.preventDefault();
     if(this.state.name =='' || this.state.weight =='' || this.state.height==''){
        alert("Fill all the fields")
     }

     else{
      if(this.state.selectedWeightMetric == 'pound'){
              this.state.weight = (parseInt(this.state.weight) / 2.20462)
          }

          if(this.state.selectedHeightMetric =='cm'){
                   this.state.height = (parseInt(this.state.height) / 100)
          }
          console.log("weight" + this.state.weight)

          console.log("height" + this.state.height)

          let x = parseFloat(this.state.weight) / (parseFloat(this.state.height)* parseFloat(this.state.height));
          this.setState({bmiNumber: x})
         if(x <= 24){
          this.setState({bmiStatus:"Under Weight"});

         }
         else if(x >= 30){
                    this.setState({bmiStatus:"Over Weight" });
                    }

          else {
                        this.setState({bmiStatus:"Healthy"});

               }
     }


     }

    onWeightChange = (event) => {
       this.setState({weight: event.target.value});

     }

     onHeightChange = (event) => {
          this.setState({height: event.target.value});

        }

      onNameChange = (event) => {
                this.setState({name: event.target.value});

              }

       onWeightMetric =(event)=>{
       this.setState({selectedWeightMetric:event.target.value})
       }

        onheightMetric =(event)=>{
                 this.setState({selectedHeightMetric:event.target.value})
              }

   render()
    {
                    let header = '';
                    if (this.state.bmiStatus) {
                      header = <h1>Hello {this.state.name} !!! Your BMI number is {this.state.bmiNumber} and you are {this.state.bmiStatus}</h1>;


                    } else {
                      header = <h1>BMI CALCULATOR</h1>
                    }



   return(
          <form >
                    {header}
                     <div >
                          <p><label>Enter your Name</label></p>
                          <input   type="text"  onChange ={this.onNameChange}/>
                      </div>

                       <div >
                         <p><label>Enter your Weight </label>
                         <select onChange ={this.onWeightMetric}>
                                              {this.state.weightMetric.map(list =>
                                              <option key ={list} value={list}>
                                              {list}
                                              </option>
                                              )}
                                              </select></p>
                          <input type="number" step="any" onChange ={this.onWeightChange} />

                       </div>

                      <div >
                         <p><label>Enter your Height </label>
                         <select onChange ={this.onheightMetric}>
                                              {this.state.heightMetric.map(list =>
                                              <option key ={list} value={list}>
                                              {list}
                                              </option>
                                              )}
                                              </select></p>
                    <input type="number"  step="any" onChange ={this.onHeightChange}  />
                       </div>

                     <div >
                     <input type='submit'  value ="Submit" onClick={this.calculatebmi}/>
                     </div>
                     <div >
                     <input type='submit' value="Reset" onClick={this.reset}/>
                                          </div>
           </form>
   );

          }
  }


ReactDOM.render(<Calculator />, document.getElementById('root'));


